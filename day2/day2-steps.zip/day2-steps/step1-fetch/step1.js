const fetch = require("fetch");
const fs = require("node:fs");
let filename = process.argv[2] || "google";
fetch.fetchUrl("https://www."+filename+".com",function(error, meta, data){
   fs.writeFile("temp/"+filename+".html",data,"utf-8",function(error){
    if(error){ console.log("Error ", error) }
    else{
        console.log("File is now ready");
    }
   })
})
/* 
npm init -y
npm i fetch
*/