const fs = require("node:fs");
const axios = require("axios");
let filename = process.argv[2];
if(filename){
    axios.get(`https://www.${filename}.com`)
    .then( res => fs.writeFile(`temp/${filename}.html`, res.data, "utf-8", function(){
        console.log("file created")
    }))
    .catch(err => console.log("Error ", err) )
}else{
    console.log("enter a domain name");
}