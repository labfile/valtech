const http = require("node:http");
const fs = require("node:fs");

let loadfile = function(args,res,message){
    fs.readFile(args,"utf-8",(err, data) => {
        res.writeHead(200, {'Content-Type' : "text/html"});
        res.write(data.replace("{{ company }}", message));
        res.end(); 
     });
};

let server = http.createServer(function(req, res){
   if(req.url == "/favicon.ico"){
        res.end(); 
    }else if(req.url == "/" ){
        loadfile("./home.html",res,"Valtech Bangalore");
     }else if(req.url == "/about.html"){
        loadfile("./about.html",res,"Valtech Pune");
    }else if(req.url == "/contact.html"){
        loadfile("./contact.html",res,"Valtech Gurugram")
   }else{
        loadfile("./404.html")
   }
});

server.listen(1010, "localhost", function(error){
    error 
    ? 
    console.log("Error ", error ) 
    : 
    console.log("server is now ready on localhost:1010")
})