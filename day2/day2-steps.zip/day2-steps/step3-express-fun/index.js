const express = require("express");
let app = express();
app.get("/", function(req, res){
    res.sendFile(__dirname+"/home.html");
});
app.get("/about", function(req, res){
    res.sendFile(__dirname+"/about.html");
});
app.get("/contact", function(req, res){
    res.sendFile(__dirname+"/contact.html");
});
app.get("**", function(req, res){
    res.sendFile(__dirname+"/404.html");
});
let url = app.listen();
console.log("webserver is now live on localhost:", url.address().port);