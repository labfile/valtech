const express = require("express");

let app = express();

app.get("/",function(req, res){
    res.render("home.pug",{ company : "Valtech" });
})

app.listen(5050,"localhost");
console.log("server is now live on localhost:5050")