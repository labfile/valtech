var user = "vijay";
var company = "Valtech";
var saymessage = function(){
    return "Good Morning";
}
// console.log(user);
// for(let i = 0; i < 10; i++){
//     console.log(user);
// };

// common js
// named export 
/* 
module.exports.company = company;
module.exports.user = user;
module.exports.saymessage = saymessage; 
*/

// default export 
/* module.exports = {
    company : company,
    user : user,
    saymessage : saymessage,
} */

module.exports = { company, user, saymessage }