const fs = require("node:fs");
/* 
let data = fs.readFileSync("data/temp.txt","utf-8");
console.log(data) 
*/
fs.readFile("data/temp.txt",function(error, data){
    if(error){
        console.log("Error ", error)
    }else{
        // console.log(data+"")
        console.log(data.toString())
    }
});


