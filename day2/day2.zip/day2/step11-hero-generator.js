const fs = require("node:fs");

let tempdata = JSON.parse(fs.readFileSync("data/herolist.json","utf-8"));

// let herolist = tempdata.herolist;

let avengers = ["Ironman","Hulk","Thor","Spiderman","Vision","Dr Strange"]
let cities = ["New York","Bangalore","Pune","Delhi","Mysore"]
function herogen(){
    let randnum = Math.ceil(Math.random() * avengers.length-1);
    let temphero = avengers[randnum];
    console.log(randnum, temphero);
    let heroobj = {
        title : temphero,
        city : cities[Math.ceil(Math.random() * avengers.length-1)],
        photo : "images/"+temphero.toLowerCase()+".jpg",
        power : Math.round( Math.random() * 100 )
    }
    tempdata.herolist.push(heroobj);
    if(tempdata.herolist.length > 100){
        clearInterval(si);
        console.log("avengers ready")
    }
    fs.writeFile("data/herolist.json",JSON.stringify(tempdata),{ encoding : "utf-8" },function(error){
        if(error){ console.log("Error ", error)}
        else{ console.log("file updated")}
    })
}
let si = setInterval(herogen,2000);