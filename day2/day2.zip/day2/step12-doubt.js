let avengers = ["Ironman","Hulk","Thor","Spiderman","Vision","Dr Strange"]
let cities = ["New York","Bangalore","Pune","Delhi","Mysore"]


setInterval(function(){
    let randomhero = Math.ceil(Math.random() * avengers.length-1);
    let randomcity = Math.ceil(Math.random() * cities.length-1);
    console.log(cities.length, randomcity )
    console.log(avengers.length, randomhero )
},600)