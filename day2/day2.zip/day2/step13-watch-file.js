const fs = require("fs");

fs.watchFile("data/herolist.json",function(){
    console.log("herolist was updated");
});
