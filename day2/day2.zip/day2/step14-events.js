const EventEmitter = require("node:events").EventEmitter
let valtechEvent = new EventEmitter();
// valtechEvent.setMaxListeners(4);
let postLunchListener = function(evt){
    console.log("postlunch event happened", evt);
};
// valtechEvent.once("postlunch", postLunchListener);
// valtechEvent.off("postlunch", postLunchListener);
// valtechEvent.addListener("postlunch", postLunchListener);
valtechEvent.on("postlunch", postLunchListener);
valtechEvent.emit("postlunch","training started");
valtechEvent.emit("postlunch","training started");
// valtechEvent.off("postlunch", postLunchListener);
valtechEvent.emit("postlunch","training started");
valtechEvent.emit("postlunch","training started");
valtechEvent.emit("postlunch","training started");