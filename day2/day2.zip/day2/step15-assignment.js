const EventEmitter = require("node:events").EventEmitter
let myEvent = new EventEmitter();
let count = 0;
function valtechListener(){
    console.log("Valtech Event happened");
};
myEvent.on("valtech", valtechListener);
let si = setInterval(function(){
    count++;
    if(count <= 5){
        myEvent.emit("valtech");
    }else{
        clearInterval(si);
        myEvent.off("valtech", valtechListener);
    }
    console.log("interval was called");
},1000);