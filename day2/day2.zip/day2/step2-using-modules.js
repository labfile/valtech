let mod = require("./step1-helloworld.js");

console.log(mod.saymessage());