const os = require("os");
console.log(os.arch());
console.log("++++++++++++++++++++++");
console.log(os.cpus()[0]);
console.log("++++++++++++++++++++++");
console.log(os.cpus().length);
console.log(((os.totalmem()/1024) / 1024) / 1024, "Gb");
console.log(os.freemem());
console.log(process.ppid);