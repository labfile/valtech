const path = require("path");
let filepath = path.join("images","rajani.jpg");
console.log(filepath);