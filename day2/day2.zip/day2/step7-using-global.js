require("./step6-set-global");

console.log(company)