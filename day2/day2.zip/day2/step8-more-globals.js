console.log(__filename);
console.log(__dirname);
console.log(process.cwd());