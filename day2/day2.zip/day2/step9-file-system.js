const fs = require("node:fs");
/* 
fs.writeFileSync("temp.txt","welcome to your life");
console.log("file is now ready"); 
*/

console.log("code in line 7");
function callbackfun(error){
        if(error){
            console.log("Error", error);
        }else{
            console.log("code in line 12");
            console.log("File is ready");
        }
};

fs.writeFile("data/temp.txt",`welcome to your life, 
there's no turning back`, callbackfun);

console.log("code in line 20");