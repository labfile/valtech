const express = require("express");
const mongoose = require("mongoose");
const config = require("./config.json");
const routes = require("./routes/approutes");
const app = express();
//----------------------------------------
// express settings 
app
.use(express.static(__dirname+"/public"))
.use(express.json())
.use(routes);
//----------------------------------------
// DB settings 
mongoose.connect(config.cloudDB)
.then( res => console.log("DB Connected") )
.catch( err => console.log("DB Not Connected", err) );
//----------------------------------------
// Routing settings 
// READ
//----------------------------------------
// server settings 
//----------------------------------------
app.listen(config.port, config.host, (error) => 
error 
? console.log("Error ", error) 
: console.log(`Server is now live on ${config.host} : ${config.port}`)
)