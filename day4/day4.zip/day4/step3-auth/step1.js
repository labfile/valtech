const express = require("express");
const app = express();
app.get("/", (req, res) => {
    res.render("home.pug")
});
app.get("/login", (req, res) => {
    res.render("login.pug")
});
app.post("/login", (req, res) => {
    res.render("login.pug")
});
app.get("/register", (req, res) => {
    res.render("register.pug")
});
app.post("/register", (req, res) => {
    res.render("register.pug")
});
app.get("/profile", (req, res) => {
    res.render("profile.pug")
});
app.get("/logout", (req, res) => {
    res.redirect("/")
});
app.listen(3030,"localhost", function(err){
    if(err){ console.log("Error ", err) }
    else{ console.log("server is now live on localhost:3030")}
})