const express = require("express");
const mongoose = require("mongoose");
const app = express();

app.use(express.urlencoded({extended : true}));

// db config
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let User = mongoose.model("User",Schema({
    id : ObjectId,
    firstname : String,
    lastname : String,
    email : { type : String, unique : true },
    password : String
}));

mongoose.connect("mongodb://127.0.0.1:27017/valtechDB")
.then( res => console.log("DB Connected"))
.catch( err => console.log("Error ", err))

app.get("/", (req, res) => {
    res.render("home.pug")
});
app.get("/login", (req, res) => {
    res.render("login.pug")
});
app.post("/login", (req, res) => {
    User.findOne({email : req.body.email})
    .then( dbres => {
        if(req.body.password === dbres.password){
           // res.render("profile.pug", { userinfo : dbres })
           res.redirect("/profile");
        }else{
            res.render("login.pug", { error : "invalid email id or password"})
        }
    })
    .catch(err => {
        res.render("login.pug", { error : "no user by that credentials"})
    })
});
app.get("/register", (req, res) => {
    res.render("register.pug")
});
app.post("/register", (req, res) => {
    let user = new User(req.body);
    user.save()
    .then( dbres => {
        console.log(dbres);
        res.render("register.pug",{ message : " user registered"})
    })
    .catch( error => {
        if(error.code == 11000){
            res.render("register.pug",{ errormessage : "email already exists"})
        }else{
            res.render("register.pug",{ errormessage : "something went wrong please try again"})
        }
    })
});
app.get("/profile", (req, res) => {
    // console.log(req)
    res.render("profile.pug")
});
app.get("/logout", (req, res) => {
    res.redirect("/")
});
app.listen(3030,"localhost", function(err){
    if(err){ console.log("Error ", err) }
    else{ console.log("server is now live on localhost:3030")}
})