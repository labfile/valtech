const express = require("express");
const mongoose = require("mongoose");
const session = require("client-sessions");
const config = require("./config.json");
const app = express();

app.use(express.urlencoded({extended : true}));
app.use( session({
    cookieName : "valtech",
    secret : "e5tyukmngfdew34567u8ijnhbvcdswe45r6y7uikjnhbgvfdswe34567yuikmnbvcf",
    duration : 1000 * 60 * 30,
    activeDuration : 1000 * 60 * 10,
    cookie : {
       ephemeral : true
    }
}) );

// db config
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let User = mongoose.model("User",Schema({
    id : ObjectId,
    firstname : String,
    lastname : String,
    email : { type : String, unique : true },
    password : String
}));

mongoose.connect(config.localDB)
.then( res => console.log("DB Connected"))
.catch( err => console.log("Error ", err))

app.get("/", (req, res) => {
    res.render("home.pug")
});
app.get("/login", (req, res) => {
    res.render("login.pug")
});
app.post("/login", (req, res) => {
    User.findOne({email : req.body.email})
    .then( dbres => {
        if(req.body.password === dbres.password){
           // res.render("profile.pug", { userinfo : dbres })
           req.valtech.user = dbres;
           res.redirect("/profile");
        }else{
            res.render("login.pug", { error : "invalid email id or password"})
        }
    })
    .catch(err => {
        res.render("login.pug", { error : "no user by that credentials"})
    })
});
app.get("/register", (req, res) => {
    res.render("register.pug")
});
app.post("/register", (req, res) => {
    let user = new User(req.body);
    user.save()
    .then( dbres => {
        console.log(dbres);
        res.render("register.pug",{ message : " user registered"})
    })
    .catch( error => {
        if(error.code == 11000){
            res.render("register.pug",{ errormessage : "email already exists"})
        }else{
            res.render("register.pug",{ errormessage : "something went wrong please try again"})
        }
    })
});
app.get("/profile", (req, res) => {
   if(req.valtech && req.valtech.user){
    User.findOne({ email : req.valtech.user.email })
    .then(dbres => {
        res.render("profile.pug", { userinfo : dbres } )
    })
    .catch(error => {
        req.valtech.reset();
        res.redirect("/login");
    })
   }else{
        res.redirect("/login");
   }
});
app.get("/logout", (req, res) => {
    req.valtech.reset();
    res.redirect("/");
});
app.listen(config.port,config.host, function(err){
    if(err){ console.log("Error ", err) }
    else{ console.log("server is now live on localhost:3030")}
})