"use strict";
/*
module.exports = {
    saymessage : function(){
        return "welcome to your life"
    }
}
*/
/*
var user = "Vijay";
console.log(user+" says hi")
*/
const express = require("express");
let app = express();
app.get("/", function (req, res) {
    res.send("welcome to home page");
});
app.get("/about", function (req, res) {
    res.send("welcome to about page");
});
app.get("/contact", function (req, res) {
    res.send("welcome to contact page");
});
app.get("**", function (req, res) {
    res.send("/404.html");
});
app.listen(5050);
console.log("webserver is now live on localhost:5050");
