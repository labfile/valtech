document.addEventListener("DOMContentLoaded", function(){
    // alert("Hello from Webpack");
    let elm = document.getElementById("root");
    if(elm){
        elm.innerHTML = "Hello there";
    }
})