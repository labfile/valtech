"use strict";
let message = "Welcome to your life";
let val = 555;
let users = ['batman', 'superman', 'flash'];
// let vals:(number | string) = true;
function adder(num1, num2) {
    console.log(num1 + num1);
}
;
class Hero {
    constructor(power, title, firstname, lastname) {
        this.power = power;
        this.title = title;
        this.firstname = firstname;
        this.lastname = lastname;
        this._secret = "my secret";
    }
    fullname() {
        return this.firstname + " " + this.lastname;
    }
    get secret() {
        return this._secret;
    }
    set secret(nsecret) {
        this._secret = nsecret;
    }
}
Hero.version = 101;
adder(5, 6);
function init() {
    var _a, _b, _c;
    let elm1 = document.createElement("h1");
    elm1.innerText = message;
    let elm2 = document.createElement("h1");
    elm2.innerText = (val * val) + "";
    let elm3 = document.createElement("ol");
    users.forEach(val => {
        elm3.innerHTML += `<li>${val}</li>`;
    });
    (_a = document.getElementById("root")) === null || _a === void 0 ? void 0 : _a.appendChild(elm1);
    (_b = document.getElementById("root")) === null || _b === void 0 ? void 0 : _b.appendChild(elm2);
    (_c = document.getElementById("root")) === null || _c === void 0 ? void 0 : _c.appendChild(elm3);
}
document.addEventListener("DOMContentLoaded", init);
