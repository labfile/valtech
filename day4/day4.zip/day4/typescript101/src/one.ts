let message:string = "Welcome to your life";
let val:number = 555;
let users:Array<string> = ['batman','superman','flash'];
// let vals:(number | string) = true;

function adder(num1:number, num2?:number):void{
    console.log(num1+num1);
};

/*
class Hero{
    title = "default";
    static version = 101;
    firstname = "default";
    lastname = "default";
    #secret = "my secret";
    constructor(ht:string,hf:string,hl:string){
        this.title = ht;
        this.firstname = hf;
        this.lastname = hl;
    }
    fullname(){
        return this.firstname+" "+this.lastname;
    }
    get secret(){
        return this.#secret;
    }
    set secret(nsecret){
        this.#secret = nsecret;
    }
}
*/

interface IHero{
    title:string;
    firstname:string;
    lastname:string;
    power:number;
    fullname():string
}

class Hero implements IHero{
    static version = 101;
    private _secret = "my secret";
    constructor( 
        public power:number,
        public title:string, 
        public firstname:string, 
        public lastname:string){
    }
   fullname():string{
    return this.firstname+" "+this.lastname;
   }
   get secret(){
    return this._secret;
   }
   set secret(nsecret:string){
    this._secret = nsecret;
   }
}

adder(5,6);

function init(){
    let elm1 = document.createElement("h1");
    elm1.innerText = message;
    let elm2 = document.createElement("h1");
    elm2.innerText = (val * val)+"";
    let elm3 = document.createElement("ol");
    users.forEach(val => {
        elm3.innerHTML+= `<li>${ val }</li>`
    });
    document.getElementById("root")?.appendChild(elm1);
    document.getElementById("root")?.appendChild(elm2);
    document.getElementById("root")?.appendChild(elm3);
}

document.addEventListener("DOMContentLoaded", init);