function refresh(){
    $.ajax({
        url : "/users/data",
        success : function(res){
           $("#grid").empty();
           res.forEach((val, idx) => {
            $("#grid").append(`
            <tr>
                <td>${ idx + 1 }</td>    
                <td>${ val.title }</td>    
                <td>${ val.firstname }</td>    
                <td>${ val.lastname }</td>    
                <td>${ val.power }</td>    
                <td>${ val.city }</td>    
                <td>
                    <button data-valtech="${ val._id }" class="btn btn-warning btn-edit"> Edit </button    
                </td>    
                <td>
                    <button data-valtech="${ val._id }" class="btn btn-danger btn-delete"> Delete </button   
                </td>    
            </tr>
            `)
           });
        },
        error : function(err){
            console.log(err)
        }
    })
};

function addHeroHandler(){
    let nhero = {
        title : $("#htitle").val(),
        firstname : $("#hfname").val(),
        lastname : $("#hlname").val(),
        city : $("#hcity").val(),
        power : $("#hpower").val(),
    }
    $.ajax({
        url : "/users/data",
        method : "post",
        data : JSON.stringify(nhero),
        dataType : "json",
        contentType : "application/json",
        success : function(res){
            refresh();
            $("#htitle").val('');
            $("#hfname").val('');
            $("#hlname").val('');
            $("#hcity").val('');
            $("#hpower").val('');
        },
        error : function(err){
            console.log("Error ", err)
        }
    })
};
function editHandler(evt){
    // alert(evt.target.getAttribute("data-valtech"))
    $.ajax({
        url : "/users/edit/"+evt.target.getAttribute("data-valtech"),
        success : function(res){
            $(".editBox").show(500);
            $(".addBox").hide(500);
            $("#ehtitle").val(res.title);
            $("#ehfname").val(res.firstname);
            $("#ehlname").val(res.lastname);
            $("#ehpower").val(res.power);
            $("#ehcity").val(res.city);
            $("#ehid").val(res._id);
        },
        error : function(err){
            console.log("Error ", err)
        },
    })
}
function updateHandler(){
    let ehero = {
        title : $("#ehtitle").val(),
        firstname : $("#ehfname").val(),
        lastname : $("#ehlname").val(),
        city : $("#ehcity").val(),
        power : $("#ehpower").val(),
    }
    $.ajax({
        url : "/users/edit/"+$("#ehid").val(),
        method : "put",
        data : JSON.stringify(ehero),
        dataType : "json",
        contentType : "application/json",
        success : function(res){
            refresh();
            $(".editBox").hide(500);
            $(".addBox").show(500);
            $("#ehtitle").val('');
            $("#ehfname").val('');
            $("#ehlname").val('');
            $("#ehcity").val('');
            $("#ehpower").val('');
        },
        error : function(err){
            console.log("Error ", err)
        }
    })
};

function deleteHandler(evt){
    $.ajax({
        url : "/users/delete/"+evt.target.getAttribute("data-valtech"),
        method : "delete",
        success : function(){
            refresh();
        },
        error : function(err){
            console.log("Error ", err)
        }
    })
}
$(()=>{
    refresh();
    $(".editBox").hide();
    $("#addBtn").on("click", addHeroHandler);
    $("#grid").on("click",".btn-edit",editHandler)
    $("#grid").on("click",".btn-delete",deleteHandler)
    $("#updateBtn").on("click",updateHandler)
})