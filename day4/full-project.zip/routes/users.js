var express = require('express');
const User = require("../models/user");
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.get("/data", (req, res) => {
    User.find()
    .then( dbres => res.status(200).json(dbres))
    .catch( err => console.log("Error ", err))
})
// CREATE
router.post("/data", (req, res) => {
    let user = new User(req.body);
    user.save()
    .then( dbres => res.send({ message : dbres.title+" was added"}))
    .catch( err => console.log("Error ", err))
})
// READ TO UPDATE
router.get("/edit/:id", (req, res) => {
    User.findById({ _id : req.params.id })
    .then( dbres => {
       res.status(200).json(dbres);
    })
    .catch( err => console.log("Error", err ))
})
// UPDATE
router.put("/edit/:id", (req, res) => {
    User.findById({ _id : req.params.id })
    .then( dbres => {
        dbres.title = req.body.title;
        dbres.firstname = req.body.firstname;
        dbres.lastname = req.body.lastname;
        dbres.power = req.body.power;
        dbres.city = req.body.city;
        dbres.save()
        .then( updateres => res.status(200).json({message : updateres.title+" was updated"}))
        .catch(err => console.log("Error", err ))
    })
    .catch( err => console.log("Error", err ))
})
// DELETE
router.delete("/delete/:id", (req, res) => {
    User.findByIdAndRemove({ _id : req.params.id })
    .then( dbres => res.status(200).json({message : dbres.title +" was deleted"}))
    .catch( err => console.log("Error", err ))
});

module.exports = router;
