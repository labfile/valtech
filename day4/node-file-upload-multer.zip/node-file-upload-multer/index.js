const express = require("express");
const app = express();
const multer = require("multer");

let storage = multer.diskStorage({
    destination : (req, file, callback) => {
        // callback takes error and the foder name
        callback(null, 'images');
    },
    filename : (req, file, callback ) => {
        // callback takes error and the file name
        // console.log( file )
        callback(null, Date.now()+"_"+file.originalname);
    }
});

// the storage configuration is now passed to the multer so we can use it as a middleware 
const upload = multer({ storage : storage });

app.get("/", (req, res) => {
    res.render("home.pug")
});

// the multer config is now used as a middleware
app.post("/", upload.single('profilepic'), (req, res) => {
    res.send("file uploaded")
})
app.listen(3000);
console.log("Server is now live on localhost:3000");

