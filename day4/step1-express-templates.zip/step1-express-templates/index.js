const express = require("express");
const fs = require("node:fs");
const config = require("./config.json");
const data = require("./data/data.json")
const app = express();
// setting
app.use(express.urlencoded({ extended : true }))
let avengers = data.list;

app.get("/",(req, res) => {
  // res.render("home.ejs", { companyname : "Valtech", avengers })
  res.render("home.pug", { companyname : "Valtech", avengers })
})
app.post("/",(req, res) => {
    // console.log(req.body);
    avengers.push(req.body.avenger);
    console.log(data);
    fs.writeFile("data/data.json", JSON.stringify( data ), "utf-8", function(error){
        if(error){
            console.log("Error ", error)
        }else{
            res.redirect("/");
        }
    })
})

app.listen(config.port, config.host, (error)=>{
    if(error){
        console.log("Error ", error)
    }else{
        console.log(`Webserver is now live on ${config.host}:${config.port}`)
    }
})