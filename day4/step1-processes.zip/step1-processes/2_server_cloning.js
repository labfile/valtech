/* Step 1
const cp = require("child_process");
cp.fork("./1_server",[3001]);
cp.fork("./1_server",[3002]);
cp.fork("./1_server",[3003]);
cp.fork("./1_server",[3004]);
cp.fork("./1_server",[3005]);
cp.fork("./1_server",[3006]); 
*/

// step 2
const cp = require("child_process");

const processes = [];

let addChild = (num) => {
    for(let i = 0; i < num; i++){    
        cp.fork("./1_server",[300+[i+1]])
    }
};

addChild(5);

console.log(processes.length,"processes are now at work")