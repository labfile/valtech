/* 
The Worker _threads module enables the use of threads 
that execute javascript in parallel

Code executed in a worker thread runs in a seperate child process, 
preventing it from blocking your main application

While cluster module can be used to run multiple instances of nodejs 
to distribute workload, worker_threads module allows running multiple 
application within a single nodejs instance
*/

const http = require("http");

const server = http.createServer((req, res) => {
    if(req.url == "/"){
        res.writeHead(200, { "Content-Type" : "text/plain"});
        res.end("welcome to home page")
    }else if(req.url == "/delay"){
        let count = 0;
        let start = Date.now();
        for(let i = 0; i < 10**10; i++){
            count++;
        };
        res.writeHead(200, { "Content-Type" : "text/plain"});
        res.end(`delayed page ${ (Date.now() - start) / 1000} seconds was taken to count till ${count}`);
    }else{
         res.end("404 page")
    }
});

server.listen(5000, () => console.log("server is running on port 5000 "));

