const http = require("node:http");
const { Worker } = require("node:worker_threads");
 
const server = http.createServer((req, res) => {
    if(req.url == "/"){
        res.writeHead(200, { "Content-Type" : "text/plain"});
        res.end("welcome to home page")
    }else if(req.url == "/delay"){
        let start = Date.now();
        const worker = new Worker("./worker_to_counter.js");
        worker.on("message", (data)=>{
            res.writeHead(200, { "Content-Type" : "text/plain"});
            res.end(`delayed page ${ (Date.now() - start) / 1000} seconds was taken to count till ${data}`);
        })
       
    }else{
         res.end("404 page")
    }
});

server.listen(5000, () => console.log("server is running on port 5000 "));

