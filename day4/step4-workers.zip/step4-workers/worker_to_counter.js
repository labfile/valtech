const { parentPort } = require("node:worker_threads");

let message = 0;

for(let i = 0; i < 10**10; i++){
    message++;
};

parentPort.postMessage(message);